# SJ Tech Solutions website

Static website (plain HTML/CSS/JS, no build step) for GitHub Pages.

```
index.html                         home: the apps, about, contact
church-management-system/          Church Management System page
assets/css/site.css                styles (colours at the top)
assets/js/site.js                  GitHub user / repository for the download links
assets/img/                        logos
assets/screens/                    screenshots (made with demo data)
```

## Publish on GitHub Pages (once)

1. Create a GitHub account if you do not have one, then a **public** repository.
   * Name it `<your-username>.github.io` for the address `https://<your-username>.github.io`,
     or any name (for example `sj-it-services`) for `https://<your-username>.github.io/sj-it-services`.
2. Upload everything in this folder (Add file > Upload files, drag the folder contents, Commit).
3. Repository **Settings > Pages**: Source "Deploy from a branch", branch `main`, folder `/ (root)`, Save.
   The site is live a minute later at the address shown there.
4. Open `assets/js/site.js` and set `GITHUB_USER` (your username) and `GITHUB_REPO`
   (the repository that holds the downloads, see below). Commit.

## Put the Windows setup online (each new version)

The setup (~130 MB) is too big for the website itself; GitHub Releases holds it (up to 2 GB per file, free).

1. On your PC, in the `Installer` folder:
   ```powershell
   .\Export-DatabaseSchema.ps1 -Public     # empty database + generic lists only
   .\Build-Installer.ps1 -Public           # signed setup, no certificate prompt
   ```
2. On GitHub, open the repository named in `GITHUB_REPO` (for example `church-management-system`;
   it can be this website repository) > **Releases > Draft a new release**.
   * Tag: the version, for example `v2026.10.17.4`
   * Title: `Church Management System 2026.10.17.4`
   * Drag `Installer\Output\ChurchManagementSystem-Setup-2026.10.17.4.exe` into the files box
   * A few lines on what is new, then **Publish release**.
3. The "Download for Windows" buttons always open the latest release.

After a public build, run `.\Export-DatabaseSchema.ps1` (without `-Public`) again before building
a setup for your own church, so it gets your areas, committee years and guest speakers back.

## Custom domain (optional)

Settings > Pages > Custom domain, then add the DNS records GitHub shows at your domain registrar.
