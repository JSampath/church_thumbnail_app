// SJ Tech Solutions — small site script (no libraries).
//
// ── SETTINGS: change these two lines after creating the GitHub repository ──
// Downloads point at the latest GitHub Release of this repository.
const GITHUB_USER = "JSampath";
const GITHUB_REPO = "church-management-system-setup";

(function () {
  "use strict";

  // Download buttons → latest release (the release page lists the setup file).
  const releases = `https://github.com/${GITHUB_USER}/${GITHUB_REPO}/releases/latest`;
  const buttons = document.querySelectorAll("[data-download]");
  buttons.forEach(a => { a.href = releases; });

  // Point the buttons straight at the setup file of the latest release (not the release page,
  // which also lists GitHub's automatic "Source code" downloads). Falls back to the release page.
  if (buttons.length) {
    fetch(`https://api.github.com/repos/${GITHUB_USER}/${GITHUB_REPO}/releases/latest`)
      .then(r => (r.ok ? r.json() : null))
      .then(rel => {
        const exe = rel && (rel.assets || []).find(x => /\.exe$/i.test(x.name));
        if (!exe) return;
        const mb = Math.round(exe.size / 1048576);
        const version = (rel.tag_name || "").replace(/^v/i, "");
        buttons.forEach(a => {
          a.href = exe.browser_download_url;
          a.setAttribute("download", "");
          a.title = `${exe.name} (${mb} MB)`;
        });
        document.querySelectorAll("[data-version]").forEach(el => {
          el.textContent = `Version ${version}, ${mb} MB`;
        });
      })
      .catch(() => { /* keep the release page link */ });
  }
  document.querySelectorAll("[data-issues]").forEach(a => { a.href = `https://github.com/${GITHUB_USER}/${GITHUB_REPO}/issues`; });

  // Home page: "Changing communities | churches | families … with tech solutions."
  const rot = document.querySelector("[data-rotate]");
  if (rot && !window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
    const words = rot.dataset.rotate.split("|");
    let i = 0;
    rot.setAttribute("aria-live", "off");   // decorative motion: don't announce every change
    setInterval(() => {
      rot.classList.add("out");
      setTimeout(() => {
        i = (i + 1) % words.length;
        rot.textContent = words[i];
        rot.classList.remove("out");
      }, 350);
    }, 2600);
  }

  // Year in the footer.
  document.querySelectorAll("[data-year]").forEach(el => { el.textContent = new Date().getFullYear(); });

  // Screenshot viewer: click a screenshot to see it full size, Esc or click to close.
  const box = document.querySelector(".lightbox");
  if (box) {
    const big = box.querySelector("img");
    const close = box.querySelector("button");
    let opener = null;
    const hide = () => { box.classList.remove("open"); big.removeAttribute("src"); if (opener) opener.focus(); };
    document.querySelectorAll(".shots button").forEach(btn => {
      btn.addEventListener("click", () => {
        const img = btn.querySelector("img");
        if (!img) return;
        opener = btn;
        big.src = img.currentSrc || img.src;
        big.alt = img.alt;
        box.classList.add("open");
        close.focus();
      });
    });
    close.addEventListener("click", hide);
    box.addEventListener("click", e => { if (e.target === box) hide(); });
    document.addEventListener("keydown", e => { if (e.key === "Escape" && box.classList.contains("open")) hide(); });
  }

  // Feature index: highlight the module being read.
  const links = [...document.querySelectorAll(".module-index a")];
  if (links.length && "IntersectionObserver" in window) {
    const byId = new Map(links.map(a => [a.getAttribute("href").slice(1), a]));
    const io = new IntersectionObserver(entries => {
      entries.forEach(en => {
        if (!en.isIntersecting) return;
        links.forEach(a => a.classList.remove("on"));
        const a = byId.get(en.target.id);
        if (a) a.classList.add("on");
      });
    }, { rootMargin: "-20% 0px -70% 0px" });
    byId.forEach((_, id) => { const el = document.getElementById(id); if (el) io.observe(el); });
  }
})();
